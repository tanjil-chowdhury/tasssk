interface IUpDateStatus{
    id:string;
    status:string;
}

export {IUpDateStatus};