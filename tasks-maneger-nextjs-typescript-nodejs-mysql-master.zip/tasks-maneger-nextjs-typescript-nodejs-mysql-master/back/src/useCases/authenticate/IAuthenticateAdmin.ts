interface IAuthenticateAdmin{
    email: string;
    password: string;
}

export {IAuthenticateAdmin};