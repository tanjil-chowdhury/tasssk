interface IRequest {
    name: string;
    email: string;
    idAdmin: string;
}
export {IRequest};