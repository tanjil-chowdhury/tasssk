interface IDeleteTask{
    id:string;
}
export {IDeleteTask};