interface ICreateTaskDTO{
    name:string;
    description:string;
    status:string;
    idUser:string;
}

export {ICreateTaskDTO};