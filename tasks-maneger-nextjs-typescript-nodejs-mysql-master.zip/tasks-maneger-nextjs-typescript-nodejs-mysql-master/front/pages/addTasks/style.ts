import styled from "styled-components";

export const Container = styled.div`
    display: flex;
    
    .header{
        flex:1;
    }
`;